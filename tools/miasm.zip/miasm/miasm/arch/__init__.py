"Architecture implementations"
