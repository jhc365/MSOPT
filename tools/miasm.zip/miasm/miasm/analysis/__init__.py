"High-level tools for binary analysis"
